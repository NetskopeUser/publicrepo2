# Calender-app-in-C-by-ganesh-kavhar
ganesh kavhar projects


Calender app provides 4 option to users is as follows..

1. Find Out the Day
2. Print all the day of month
3. Add Note
4. EXIT
ENTER YOUR CHOICE :



/* User nedd to enter the entries as per requirement.*/

